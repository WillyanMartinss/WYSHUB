param(
    [string]$SourcePath = ''
)

$ErrorActionPreference = 'Stop'

$AppFolder = Join-Path $env:ProgramFiles 'WYSHUB'
$ExeName = 'WYSHUB.exe'
$SourceAppPath = if ($SourcePath) { $SourcePath } else { Split-Path $PSScriptRoot -Parent }
$SourceExePath = Join-Path $SourceAppPath $ExeName
$TargetExePath = Join-Path $AppFolder $ExeName
$RequirementsPath = Join-Path (Split-Path $SourceAppPath -Parent) 'requirements.txt'
$DocumentsFolder = [Environment]::GetFolderPath('MyDocuments')
$SetupWizardLogFolder = Join-Path $DocumentsFolder 'SystemWM\Logs'
$SetupWizardLogPath = Join-Path $SetupWizardLogFolder ('SetupWizard_{0:yyyyMMdd_HHmmss}.log' -f (Get-Date))

New-Item -ItemType Directory -Path $SetupWizardLogFolder -Force | Out-Null
Start-Transcript -Path $SetupWizardLogPath -Force | Out-Null

function Write-SetupWizardLog {
    param(
        [string]$Message
    )

    Write-Host $Message
}

function Get-WingetPath {
    $possiblePaths = @(
        "$env:windir\sysnative\winget.exe",
        "$env:windir\System32\winget.exe"
    )

    foreach ($path in $possiblePaths) {
        if (Test-Path $path) {
            return $path
        }
    }

    return $null
}

if (-not $SourceExePath -or -not (Test-Path $SourceExePath)) {
    $SourceAppPath = (Get-Location).Path
    $SourceExePath = Join-Path $SourceAppPath $ExeName
}

if (-not (Test-Path $SourceExePath)) {
    throw "Executável não encontrado para instalação: $SourceExePath"
}

function Test-DotNet8Runtime {
    try {
        $output = & dotnet --list-runtimes 2>$null
        return $output -match 'Microsoft.NETCore.App 8'
    }
    catch {
        return $false
    }
}

function Test-VisualCppRedist {
    try {
        $keys = @(
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
        )

        foreach ($k in $keys) {
            $items = Get-ItemProperty $k -ErrorAction SilentlyContinue
            if ($items) {
                foreach ($it in $items) {
                    $dn = $it.DisplayName
                    if ($dn -and $dn -match 'Visual C\+\+' -and $dn -match 'Redistributable') {
                        return $true
                    }
                }
            }
        }

        return $false
    }
    catch {
        return $false
    }
}

function Test-WmiService {
    try {
        $status = sc.exe query winmgmt 2>$null
        return ($status -match 'RUNNING') -or ($status -match 'START_PENDING')
    }
    catch {
        return $false
    }
}

function Install-RequirementItem {
    param(
        [string]$ItemName,
        [scriptblock]$CheckScript,
        [scriptblock]$InstallScript
    )

    Write-SetupWizardLog "Verificando: $ItemName"
    if (& $CheckScript) {
        Write-SetupWizardLog "PASS: $ItemName já está presente no sistema."
        return $true
    }

    Write-SetupWizardLog "FAIL: $ItemName não está presente. Iniciando instalação..."
    try {
        Write-SetupWizardLog "DEBUG: Executando script de instalação para: $ItemName"
        & $InstallScript
        if (& $CheckScript) {
            Write-SetupWizardLog "INSTALLED: $ItemName instalado com sucesso."
            return $true
        }
        else {
            Write-SetupWizardLog "ERROR: A instalação de $ItemName não foi confirmada após a execução do instalador."
            return $false
        }
    }
    catch {
        $ex = $_.Exception
        Write-SetupWizardLog ("ERROR: Falha ao instalar {0}: {1}\nStackTrace:\n{2}\nInvocationInfo:\n{3}" -f $ItemName, $ex.Message, $ex.StackTrace, $_.InvocationInfo | Out-String)
        return $false
    }
}

try {
    New-Item -ItemType Directory -Path $AppFolder -Force | Out-Null
    Write-SetupWizardLog '== Assistente de instalação do WYSHUB =='
    Write-SetupWizardLog "Log do assistente: $SetupWizardLogPath"
    Write-SetupWizardLog '1) Instalando arquivos no diretório do programa...'

    if ($SourceAppPath -ne $AppFolder) {
        Copy-Item -Path (Join-Path $SourceAppPath '*') -Destination $AppFolder -Recurse -Force
    }

    Write-SetupWizardLog '2) Criando atalhos...'
    try {
        $shell = New-Object -ComObject WScript.Shell
        $desktopPath = [Environment]::GetFolderPath('Desktop')
        $startMenuPath = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\WYSHUB'
        New-Item -ItemType Directory -Path $startMenuPath -Force | Out-Null

        $desktopShortcut = Join-Path $desktopPath 'WYSHUB.lnk'
        $shortcut = $shell.CreateShortcut($desktopShortcut)
        $shortcut.TargetPath = $TargetExePath
        $shortcut.WorkingDirectory = $AppFolder
        $shortcut.IconLocation = $TargetExePath
        $shortcut.Save()

        $startMenuShortcut = Join-Path $startMenuPath 'WYSHUB.lnk'
        $shortcut = $shell.CreateShortcut($startMenuShortcut)
        $shortcut.TargetPath = $TargetExePath
        $shortcut.WorkingDirectory = $AppFolder
        $shortcut.IconLocation = $TargetExePath
        $shortcut.Save()

        Write-SetupWizardLog 'Atalhos criados.'
    }
    catch {
        Write-Warning "Não foi possível criar atalhos: $($_.Exception.Message)"
    }

    Write-SetupWizardLog '3) Verificando o checklist de requisitos item por item...'
    $allSucceeded = $true
    Write-SetupWizardLog "DEBUG: env:windir value = $env:windir"
    try { Write-SetupWizardLog "DEBUG: env:windir type = $($env:windir.GetType().FullName)" } catch { Write-SetupWizardLog "DEBUG: não foi possível obter o tipo de env:windir" }

    $res = Install-RequirementItem -ItemName '.NET 8 Desktop Runtime x64' -CheckScript { Test-DotNet8Runtime } -InstallScript {
        $wingetPath = Get-WingetPath
        Write-SetupWizardLog "DEBUG: wingetPath = $wingetPath"
        if (-not $wingetPath) {
            Write-SetupWizardLog 'ERROR: winget não foi encontrado. Instale o runtime .NET 8 manualmente.'
            return $false
        }

        try {
            $p = Start-Process -FilePath $wingetPath -ArgumentList 'install','--id','Microsoft.DotNet.Runtime.8','--source','winget','--accept-source-agreements','--accept-package-agreements','-e' -NoNewWindow -PassThru -Wait
            Write-SetupWizardLog "DEBUG: winget exit code: $($p.ExitCode)"
            if ($p.ExitCode -ne 0) { Write-SetupWizardLog 'ERROR: winget retornou código de erro ao tentar instalar .NET 8.'; return $false }
        }
        catch {
            Write-SetupWizardLog ("ERROR: Falha ao executar winget para .NET: {0}" -f $_.Exception.Message)
            return $false
        }
    }
    $allSucceeded = $allSucceeded -and $res

    $res = Install-RequirementItem -ItemName 'Visual C++ Redistributable 2015-2022 x64' -CheckScript { Test-VisualCppRedist } -InstallScript {
        $wingetPath = Get-WingetPath
        Write-SetupWizardLog "DEBUG: wingetPath = $wingetPath"
        if ($wingetPath) {
            try {
                $p = Start-Process -FilePath $wingetPath -ArgumentList 'install','--id','Microsoft.VCRedist.2015+.x64','--source','winget','--accept-source-agreements','--accept-package-agreements','-e' -NoNewWindow -PassThru -Wait
                Write-SetupWizardLog "DEBUG: winget exit code: $($p.ExitCode)"
                if ($p.ExitCode -eq 0) { return $true }
                Write-SetupWizardLog 'WARN: winget não conseguiu instalar o Visual C++; tentando fallback via download direto.'
            }
            catch {
                Write-SetupWizardLog ("ERROR: Falha ao executar winget para Visual C++: {0}" -f $_.Exception.Message)
            }
        }

        # Fallback: baixar instalador oficial da Microsoft e executar silenciosamente
        try {
            Write-SetupWizardLog "DEBUG: env:TEMP value: $env:TEMP"
            try { Write-SetupWizardLog "DEBUG: env:TEMP type: $($env:TEMP.GetType().FullName)" } catch { Write-SetupWizardLog "DEBUG: não foi possível obter tipo de env:TEMP" }
            $tempFile = Join-Path $env:TEMP 'vc_redist.x64.exe'
            $vcUrl = 'https://aka.ms/vs/17/release/vc_redist.x64.exe'
            Write-SetupWizardLog "INFO: Baixando Visual C++ de: $vcUrl para $tempFile"
            Invoke-WebRequest -Uri $vcUrl -OutFile $tempFile -UseBasicParsing -ErrorAction Stop
            Write-SetupWizardLog 'INFO: Executando instalador do Visual C++ (silencioso).'
            Start-Process -FilePath $tempFile -ArgumentList '/install','/quiet','/norestart' -Wait -NoNewWindow
            Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
            Write-SetupWizardLog 'INFO: Instalador de Visual C++ concluído (fallback).' 
            return $true
        }
        catch {
            Write-SetupWizardLog ("ERROR: Falha no fallback do Visual C++: {0}" -f $_.Exception.Message)
            return $false
        }
    }
    $allSucceeded = $allSucceeded -and $res

    $res = Install-RequirementItem -ItemName 'Serviço WMI' -CheckScript { Test-WmiService } -InstallScript {
        sc.exe config winmgmt start= auto | Out-Null
        net start winmgmt | Out-Null
        Write-Host 'WMI habilitado.'
        return $true
    }
    $allSucceeded = $allSucceeded -and $res

    if (-not $allSucceeded) {
        Write-SetupWizardLog 'Alguns itens falharam. O assistente terminou, mas é recomendável revisar o log e executar novamente se necessário.'
        throw 'Nem todos os requisitos foram atendidos.'
    }

    Write-SetupWizardLog '4) Aplicando exclusões do Defender...'
    try {
        Add-MpPreference -ExclusionPath $AppFolder -ErrorAction SilentlyContinue
        if (Test-Path $TargetExePath) {
            Add-MpPreference -ExclusionProcess $TargetExePath -ErrorAction SilentlyContinue
        }
        Write-SetupWizardLog 'Exclusões aplicadas.'
    }
    catch {
        Write-Warning "Falha ao aplicar exclusões do Defender: $($_.Exception.Message)"
    }

    Write-SetupWizardLog 'Assistente concluído.'
}
finally {
    Stop-Transcript | Out-Null
}
